const express=require("express");
const bodyParser=require("body-parser");
const mongoose =require("mongoose");

const placeRouter=require('./routes/places-routes');
const userRouter =require('./routes/users-routes');

const app = express();

app.use(bodyParser.json());

//Middleware

app.use('/api/places',placeRouter);
app.use('/api/users',userRouter);

app.use((error,req,res,next) => {
    if(res.headerSent){
        return next(error);
    }
    res.status(error.code|| 500);
    res.json({message:error.message||"something went wrong!!"})

})

mongoose.connect('mongodb+srv://JuveriyaBegum:qq1F8shHXgO5JqOA@cluster0.ktjkigg.mongodb.net/?retryWrites=true&w=majority')
    .then(()=>{
            console.log("Connected to DataBase!");
            app.listen(5000);
    })
    .catch(err=>{
        console.log(err);
    });
