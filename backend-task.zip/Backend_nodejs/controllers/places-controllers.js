const HttpError = require("../models/http-error");
const Place =require('../models/place');

let  DUMMY_PLACES=[{
    id:"p1",
    title:"paris",
    description:"",
    address:"",
    createrId:"u1"
},
{
    id:"p2",
    title:"Atlanta",
    description:"",
    address:"",
    createrId:"u2"
},
{
    id:"p3",
    title:"Antartica",
    description:"",
    address:"",
    createrId:"u2"
}];

/*------getting data with placeid and throwing error if mention pid is not present-----*/
const getPlaceById = async (req,res,next) => {
    const placeId = req.params.pid;

    let place;
    try{
        place = await Place.findById(placeId);
    }catch(err){
        const error = new HttpError("Something went wrong!!",500);
        return next(error);
    }
    if(!place){
         const error = new  HttpError("Couldn't find place with provided id",404);
    }
    res.status(200).json({place:place.toObject({getters:true})},);
}

/*------getting data with place id and throwing error if mention pid is not present-----*/
// const getPlaceByUserId = (req,res,next) => {
//     const userId = req.params.uid;

//     const place = DUMMY_PLACES.filter(p => { 
//         return p.createrId === userId;
//     })
//     if(!place){
//          throw new HttpError("Couldn't find user with provided id",404);
//     }
//     res.json({place});
// }

/*---------getting9retrieving) data with user id-------------*/
const getPlaceByUserId = async (req,res,next)=>{
    const userId = req.params.uid;

    let places;
    try{
        places = await Place.find({createrId:userId})
    }catch(err){
        const error = new HttpError("Something went wrong!!",500);
        return next(error);
    }
    res.json({places:places.map(place=>place.toObject({getters:true}))});
}

/* Post i.e, create*/
// const createPlace = (req,res,next)=>{
//     console.log(req.body);
//     const[id, title, description, address, createrId] = req.body; 

//     const createdPlace = {id, title, description, address, createrId  }

//     //pushing object 
//     DUMMY_PLACES.push(createdPlace);

//     res.status(201).json({place:createPlace})
// }

const createPlace = async(req,res,next)=>{
    console.log(req.body);

    const {title,description,address,createrId } = req.body;
    
    const createdPlace= new Place({
                            title,
                            description,
                            address,
                            createrId
    });

    try {
        await createdPlace.save();
    }catch(err){
        const error = new HttpError('creating place failed',500);
        return next(error);
    }
    res.status(201).json({place:createdPlace});
}

    
/* Update i.e, patch Call*/

const updatePlace = (req,res,next) => {

    //object destructuring
    const {title, description} = req.body;

    const placeId = req.params.pid;

    //finding the user with the given pid
    const updatedPlace = {...DUMMY_PLACES.find(p=> p.id === placeId)};

    const placeIndex = DUMMY_PLACES.findIndex(p=> p.id === placeId);

    //updating title and description for given pid
    updatedPlace.title = title;
    updatedPlace.description =description;

    DUMMY_PLACES[placeIndex] =updatedPlace;

    res.status(200).json({place:updatedPlace});

}
  

/*delete*/
const deletePlace = (req, res, next) => {
    
    const placeId =req.params.pid;

    DUMMY_PLACES = DUMMY_PLACES.filter(p=> p.id!= placeId)
    
    res.status(200).json({Message:"Place Deleted"});
}
  

exports.getPlaceById = getPlaceById;
exports.getPlaceByUserId = getPlaceByUserId;
exports.createPlace = createPlace;
exports.updatePlace = updatePlace;
exports.deletePlace = deletePlace;