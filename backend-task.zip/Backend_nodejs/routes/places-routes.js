const express=require("express");

const app = express();

const router =express.Router();

const HttpError = require('../models/http-error');

const placeControllers =require('../controllers/places-controllers');


router.get('/:pid',placeControllers.getPlaceById);

router.get("/user/:uid",placeControllers.getPlaceByUserId);

router.post('/',placeControllers.createPlace);

router.patch('/:pid',placeControllers.updatePlace);

router.delete('/:pid',placeControllers.deletePlace);

module.exports = router




/*------- getting data with user id and throwing error if mention pid is not present---------*/

// router.get('/users/:uid',(req,res,next)=>{
//     const  userId=req.params.uid;
//     const place=DUMMY_PLACES.find(p=>{
//         return p.createrId===userId;
//     })
//     if(!place){
//         throw new HttpError("Couldn't find user with provided id",404);
//     }
//     res.json({place});
// })


  
// router.get('',(req,res,next)=>{

//     console.log("It's working!!!");
//     res.json({message:"Hello,World"});
// })


