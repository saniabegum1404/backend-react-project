const http=require('http');

const server=http.createServer((req,res)=>{
    res.write(req.url);
    if(req.url==="/posts"){

    }
    res.end();
})
server.listen(5000);